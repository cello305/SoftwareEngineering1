module.exports = {
    HOST: 'remotemysql.com',
    USER: 'CYFGNK8jlO',
    PASSWORD: 'gsINdKV9SX',
    DB: 'CYFGNK8jlO',
    dialect: 'mysql',
    socketPath: '/Applications/MAMP/tmp/mysql/mysql.sock',

    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }

}

