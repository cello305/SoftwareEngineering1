module.exports = (sequelize, Sequelize) => {

    const Product = sequelize.define("product", {
        title: {
            type: Sequelize.STRING,
            allowNull: false
        },
        price: {
            type: Sequelize.INTEGER,
        },
        user: {
            type: Sequelize.STRING
        },
        inCart: {
            type: Sequelize.BOOLEAN
        }

    })

    return Product
}
